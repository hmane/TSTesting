# Claude Code SPFx/M365 Kit

Skills, agents, and commands for SPFx / M365 / .NET / PnP PowerShell development.
Read-only by design where it matters — the review/audit tooling never modifies
your code.

## Contents

```
skills/
  feature-audit/     Static, read-only audit for flaws, hidden bugs, error-path
                     gaps. Covers SPFx (web parts + application/field/form
                     customizers), Azure Functions/.NET, PnP PowerShell.
  pr-prep/           Pre-PR quality gate: lint + tsc, SP/toolkit/React checks,
                     extension lifecycle, version sync (package.json ↔
                     package-solution.json), Deployments/<version> folder,
                     Schema-vs-code, constants (no hardcoded names), PowerShell.
agents/
  explorer.md        Read-only codebase investigator (Haiku). Explores in an
                     isolated context and returns a tight summary — keeps the
                     main session clean. Knows web parts AND extensions.
  reviewer.md        Read-only code reviewer (Sonnet). Preloads the feature-audit
                     skill and returns prioritized findings in isolation.
commands/
  audit.md           /audit <file|folder|feature> — delegates to feature-audit.
  pr-prep.md         /pr-prep [version] — runs the pr-prep gate.
  handoff.md         /handoff [note] — writes a HANDOFF.md recovery breadcrumb
                     (current task / decisions / next steps / files) so a fresh
                     session can resume after a timeout or crash.
```

## Install

Pick a scope and copy the folders in. The three top-level folders map onto the
`.claude` layout directly.

**Project / solution level** (recommended for team sharing — commit it):
```
<repo>/.claude/skills/feature-audit/
<repo>/.claude/skills/pr-prep/
<repo>/.claude/agents/explorer.md
<repo>/.claude/agents/reviewer.md
<repo>/.claude/commands/audit.md
<repo>/.claude/commands/pr-prep.md
<repo>/.claude/commands/handoff.md
```

**User level** (just you, all projects): same files under `~/.claude/...`.

Quick copy (from inside this kit folder), project scope:
```
mkdir -p <repo>/.claude/skills <repo>/.claude/agents <repo>/.claude/commands
cp -r skills/*   <repo>/.claude/skills/
cp    agents/*   <repo>/.claude/agents/
cp    commands/* <repo>/.claude/commands/
```

After copying, restart/reopen the Claude Code session — skills and file-based
agents load at session start. (Agents created via `/agents` apply immediately,
but copied files need a reopen.)

## Usage

- `/audit src/extensions/myFieldCustomizer/...` — static audit of a file/feature.
- `/pr-prep` or `/pr-prep 1.3.0` — pre-PR gate; asks per category before fixing.
- `/handoff before big refactor` — write the recovery breadcrumb.
- Agents are usually delegated automatically by the main session, or invoke
  explicitly: "use the explorer agent to map the form-customizer save flow" /
  "have the reviewer check my staged diff".

## Notes

- **Model routing:** audit/review default to Sonnet, explorer to Haiku, handoff
  to Haiku. Bump to Opus only for genuinely hairy audits.
- **Constants discipline:** the skills discover your `sp/` constants structure at
  runtime rather than assuming a shape, and flag hardcoded list/field/group
  names that should reference those constants.
- **When packaged as a plugin:** skill/command names may become namespaced
  (e.g. `/audit` → `/<plugin>:audit`). Plugin reference folders must stay
  self-contained (these are), since files outside a plugin dir aren't copied.
