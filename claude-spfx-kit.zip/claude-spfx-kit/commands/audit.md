---
description: Static audit of a file/feature for flaws, hidden bugs, and error-path gaps (read-only). Delegates to the feature-audit skill.
argument-hint: <file path, folder, or feature name>
allowed-tools: Read, Grep, Glob
model: sonnet
---

Perform a static, read-only audit of: $ARGUMENTS

Use the `feature-audit` skill and follow its workflow and report structure exactly.

Treat $ARGUMENTS as the scope to audit — it may be a single file path, a folder,
a comma-separated list of paths, or a plain-English feature name. If it's a
feature name or folder, first locate the entry points and follow the call graph
before auditing.

Do NOT run, build, modify, or execute anything — this is read-only. If a finding
can only be confirmed by execution, say so rather than guessing.

If $ARGUMENTS is empty, ask which file or feature to audit before proceeding.
