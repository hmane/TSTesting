---
description: Pre-PR quality gate for an SPFx solution — lint, tsc, SP/toolkit/React checks, version sync, Deployments, Schema, constants. Delegates to the pr-prep skill.
argument-hint: [optional: scope or target version, e.g. "1.3.0"]
allowed-tools: Read, Grep, Glob, Bash
model: sonnet
---

Run the SPFx PR-prep quality gate. Use the `pr-prep` skill and follow its
workflow and report structure exactly.

$ARGUMENTS may optionally specify a scope (subset of the solution to focus on)
or a target version to sync to (e.g. "1.3.0"). If empty, prep the whole solution
and infer the target version from package.json / package-solution.json (ask if
ambiguous).

Run lint and tsc using the project's actual scripts and use the real output.
Group findings by category and ask which categories to fix before changing any
files — do not bulk-apply fixes without approval. After applying approved fixes,
re-run lint and tsc and report the result.
