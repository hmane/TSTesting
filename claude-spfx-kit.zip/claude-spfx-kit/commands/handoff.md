---
description: Write/update a HANDOFF.md recovery breadcrumb (current task, decisions, next steps, files touched) so a fresh session can resume instantly after a timeout or crash.
argument-hint: [optional note, e.g. "before big refactor"]
allowed-tools: Read, Write, Edit, Bash(git status:*), Bash(git diff:*), Bash(git log:*)
model: haiku
---

Write or update a `HANDOFF.md` file at the repository root that lets a fresh
Claude Code session resume this work with full context after an interruption
(timeout, crash, or `/clear`).

First gather real state — do not guess:
- Current git status: !`git status --short`
- Recent commits: !`git log --oneline -8`
- Uncommitted changes: !`git diff --stat`

Then write `HANDOFF.md` using EXACTLY this structure. Overwrite the file if it
exists (it is a living snapshot, not an append log). Keep it tight and factual —
this is a breadcrumb, not documentation. Base it on what actually happened in
THIS session, plus the git state above.

```
# HANDOFF — [short task name]
_Last updated: [timestamp] · $ARGUMENTS_

## Goal
[1-2 sentences: what this session is trying to accomplish.]

## Current state
[Where things stand right now — what's done, what's in progress.]

## Key decisions
[Decisions made this session and the reasoning, so they aren't relitigated.
Bullet list. Include rejected approaches and why.]

## Next steps
[Ordered list of what to do next. Be specific enough that a fresh session can
pick up without re-deriving anything.]

## Files touched
[Files created/edited this session, with a one-line note on each. Pull from the
git status/diff above plus this session's edits.]

## Watch out for
[Gotchas, constraints, or things half-done that could trip up a resume.
Omit the section if there are none.]
```

After writing the file, confirm with a single line: the path and a one-sentence
summary of what was captured. Do not echo the whole file back.

If `$ARGUMENTS` is provided, include it as a context note next to the timestamp
(e.g. "before big refactor", "hit timeout on the schema check").
