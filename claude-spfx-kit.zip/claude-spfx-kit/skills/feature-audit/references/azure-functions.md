# Azure Functions / .NET — Audit Checklist

Detailed checks for Azure Functions and .NET backend code. Read this when the
audited code is a function app or .NET service. Work from the trigger inward.

## Trigger & input contract

- **Malformed input:** what happens on a payload missing required fields, wrong
  types, or empty body? Is input validated before use, or assumed well-formed?
- **Oversized / unexpected payloads:** large blobs, huge arrays — bounded?
- **Binding failures:** input bindings (Blob, Queue, Cosmos) that fail to
  resolve — handled or unhandled exception?
- **Trigger type fit:** HTTP trigger doing long work that should be queue/durable
  (timeout risk); timer trigger overlapping with itself on long runs.

## Idempotency & delivery semantics

- **At-least-once delivery:** Queue/Service Bus/Event triggers can deliver the
  same message more than once. If the function isn't idempotent, a retry
  double-processes (double-tags a contract, double-charges, duplicate rows).
  This is the single most common Functions correctness bug — audit it
  explicitly.
- **Poison messages:** repeated failures — is there a dead-letter / max-dequeue
  path, or does it retry forever?
- **Partial completion:** function does step A, succeeds, step B fails, message
  retried → step A runs twice. Look for non-idempotent A.

## External calls & resilience

- **Timeouts:** outbound HTTP/DB calls with no timeout can hang the whole
  invocation until the platform kills it.
- **Transient faults / retry:** retry-with-backoff (e.g. Polly) on transient
  errors, or first failure = total failure?
- **Downstream throttling:** calling Graph/SharePoint/OpenAI/Document
  Intelligence — those throttle. 429/503 handled?
- **Secrets:** connection strings, keys, tokens pulled from configuration / Key
  Vault / Managed Identity — never hardcoded, never logged.

## Async / Task correctness (.NET)

- **Unawaited tasks:** `Task` returned or created but not awaited → fire-and-
  forget, exceptions lost, work may not finish before the function returns.
- **`.Result` / `.Wait()` / `.GetAwaiter().GetResult()`:** sync-over-async,
  deadlock and thread-starvation risk. Should be `await`.
- **`async void`:** anywhere except event handlers — exceptions can't be caught.
- **CancellationToken:** the function's cancellation token threaded through to
  long calls, or ignored?
- **ConfigureAwait:** library code — relevant depending on host.

## Resource lifetime

- **HttpClient:** created per-invocation (socket exhaustion) instead of static /
  `IHttpClientFactory`.
- **Connections/streams:** `using` / disposal on DB connections, blob streams,
  readers — leaks under load.
- **Static state:** mutable static fields shared across concurrent invocations
  on the same instance → race conditions.

## Error handling & observability

- **Swallowed exceptions:** caught and logged-then-ignored where the caller
  needed to know it failed.
- **Logging:** enough context to diagnose (correlation id, input id), but no
  secrets/PII in logs.
- **Return semantics:** HTTP function returning 200 on a path that actually
  failed (silent failure to the caller).

## Two-stage pipeline note (Document Intelligence → OpenAI)

For pipelines like vendor-contract metadata extraction, additionally audit:

- The handoff between stage 1 (DI) and stage 2 (OpenAI): what if stage 1 returns
  low-confidence / empty / partial extraction — does stage 2 run on garbage?
- Confidence thresholds: is there a gate, or does everything flow through?
- Cost/throttle control on the OpenAI call under background/batch processing.
- Idempotency across the two stages if the orchestration retries.
