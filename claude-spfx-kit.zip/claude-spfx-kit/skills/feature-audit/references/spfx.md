# SPFx / React 17 + TypeScript — Audit Checklist

Detailed checks for web parts, extensions, and `spfx-toolkit`-based components.
Read this when the audited code is SPFx. Work top-down: data layer → state →
render → permissions.

## Graph & PnP JS data layer

- **Throttling (429):** Is there retry-with-backoff, or does a 429 surface as a
  generic failure / silent empty result? SharePoint and Graph throttle
  aggressively under load. Look for `Retry-After` handling.
- **Paging:** Any call returning a collection must follow `@odata.nextLink`
  (Graph) or use `.getPaged()` / `.top()` loops (PnP). A bare `.get()` that
  returns the first page only is a classic "works in dev, wrong in prod" bug —
  dev libraries are small, prod libraries aren't.
- **Batch calls:** With PnP batching or `$batch`, a partial failure can leave
  some operations done and others not. Is partial failure detected and handled,
  or assumed all-or-nothing?
- **Token / context expiry:** Long-lived components reusing a stale context or
  token. SPContext caching is great until the cached thing expires mid-session.
- **CAML / query construction:** Built by string concatenation with unescaped
  user input? Injection and malformed-query risk.

## Field-type parsing

SharePoint field shapes are a top source of silent bugs. Check each field read:

- **Lookup:** returns `{ LookupId, LookupValue }`, not a string. Reading
  `item.Vendor` directly instead of `item.Vendor.LookupValue` (or the expanded
  field) gives `[object Object]` or undefined.
- **Managed metadata (taxonomy):** has `TermGuid` / `Label` structure; multi-
  value taxonomy is an array. Easy to drop all but the first term.
- **Person/Group:** single vs multi-value; `Title` / `EMail` / `Id`. Auditing
  whether multi-person fields are handled as arrays.
- **DateTime:** timezone/UTC assumptions; SharePoint stores UTC, display is
  site-local.
- **Number/Currency/Boolean:** `null` vs `0` vs `false` confusion.

## React 17 specifics

- **ErrorBoundary placement:** Does the boundary actually wrap the subtree that
  can throw? A boundary at the root won't help if the throwing component renders
  conditionally outside it. Async errors (in effects/handlers) are NOT caught by
  error boundaries at all — check those have their own try/catch.
- **useEffect:** missing/incorrect dependency arrays causing stale closures or
  infinite loops; missing cleanup (subscriptions, timers) → leaks; effects that
  set state after unmount.
- **Render races:** two async loads where the slower one wins and overwrites
  fresher data; no request-cancellation / "is this still the latest" guard.
- **Keys:** list rendering with index keys causing state bleed across items.
- **State after unmount:** `setState` in a resolved promise after the component
  is gone → React warning + potential stale UI.

## spfx-toolkit component patterns

- **CardController singleton:** shared singleton state across multiple Card
  instances — audit for one card's state mutating another's, especially with
  maximize/accordion/state-persistence interacting.
- **spForm:** Zod validation actually wired to submit? React Hook Form +
  DevExtreme + PnP controls — check controlled/uncontrolled mismatches and that
  validation failures block submission rather than warning only.
- **spUpdater change detection:** `isEqual` comparison can return false-negative
  "no change" on deep/nested objects or reference-equal mutations → silent
  failure to save. Audit what counts as "changed."
- **Toast/Notification:** errors routed to the user, or only to console?

## Permissions & security

- **ACL trimming:** does the UI rely on server-side trimming, or does it fetch
  then filter client-side (data leak — trimmed items still hit the browser)?
- **Broken inheritance:** code that assumes inherited permissions where an item
  may have unique perms.
- **ManageAccess / GroupViewer:** elevated operations scoped correctly; no
  elevated context leaking into unrelated calls.
- **Elevated privileges:** any `AllowAppOnlyPolicy` / elevated app context used
  more broadly than the one operation that needs it.

## SPFx extensions (customizers)

Extensions live in `src/extensions/`. Each customizer type has a lifecycle whose
dispose half is the most common source of bugs — these components often run on
many pages or many cells, so a leak or un-disposed handler is a tenant-wide
performance problem, not a one-page issue. Check the type-specific contract:

### Application Customizer
- **Placeholder lifecycle:** placeholders (`Top`/`Bottom`) acquired via
  `context.placeholderProvider.tryCreateContent`; code handles the placeholder
  not being available (returns/guards rather than throwing).
- **Dispose on navigation:** placeholders and any DOM/handlers created are
  disposed in `onDispose` / when the placeholder is disposed. Runs on every
  page — a leaked placeholder or listener compounds across navigation.
- **onInit weight:** `onInit` not doing heavy synchronous work that blocks page
  render; async work awaited properly and failure-handled.
- **Re-render safety:** if it injects React, the root is unmounted on dispose
  (no orphaned React tree).

### Field Customizer
- **onRenderCell / onDisposeCell pairing:** anything rendered (especially a
  React root) in `onRenderCell` is torn down in `onDisposeCell`. This fires per
  cell per row on every list re-render — a missing dispose leaks fast.
- **Field-value parsing:** the cell value is parsed for the actual column type
  (lookup/taxonomy/person/multi-value — see field-type section above), not
  assumed to be a plain string; handles empty/null cells.
- **No per-cell heavy work:** expensive computation or data calls inside
  `onRenderCell` (runs for every visible cell) — flag and suggest hoisting.

### Form Customizer
- **onSave / onClose contract:** `onSave` validates before writing, surfaces
  save failures (doesn't swallow), and the form closes/navigates correctly;
  `onClose` handles the unsaved-changes case.
- **Display mode handling:** New vs Edit vs Display modes each handled — fields
  read-only in Display, required-field validation in New/Edit.
- **Dispose:** React root unmounted and handlers cleaned up on close.
- (Relevant to form-customizer-based workflows like legal/document review:
  verify the stage/state transitions and permission gates are enforced in code,
  not just assumed from the list configuration.)

### Registration (all extension types)
- **Manifest ↔ code:** `ClientSideComponentId` in the registration
  (elements.xml `CustomAction`, or tenant-wide deployment) matches the manifest;
  `ClientSideComponentProperties` JSON matches the typed properties the code
  expects (mismatch = silent undefined at runtime).
- **Tenant-scoped deployment:** tenant-wide / list-scoped registration is
  deliberate — flag an extension wired to run far more broadly than its purpose
  needs (every list, every page) when narrower scope would do.

## TypeScript-strict soundness

- `any` / `as any` escapes that disable type safety exactly where data shape
  matters (API responses).
- Non-null assertions (`!`) asserting something is present that the API doesn't
  guarantee.
- Unsound casts of API responses to interfaces without runtime validation —
  the compiler trusts you, production data doesn't.
