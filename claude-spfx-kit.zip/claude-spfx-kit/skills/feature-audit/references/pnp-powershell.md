# PnP PowerShell — Audit Checklist

Detailed checks for PnP PowerShell automation scripts. Read this when auditing
`.ps1` automation. These scripts often run against live tenants with broad
rights, so destructive-operation and scope checks carry extra weight.

## Connection & scope

- **Which identity / site:** `Connect-PnPOnline` target — is it the intended
  site/tenant? Scripts that take a URL parameter can be pointed at the wrong
  site. Audit whether the connection is verified before destructive work.
- **Credential handling:** interactive vs app-only vs certificate vs stored
  secret. Secrets/passwords hardcoded or in plaintext? Should be Key Vault,
  managed identity, or a secure prompt.
- **Connection reuse vs reconnect:** long scripts whose token expires mid-run.
- **Cross-site bleed:** a loop that switches sites but leaves a stale `$conn`
  context, so later ops hit the wrong site.

## Destructive operations (highest priority)

- **`Remove-*` without a guard:** deletes with no confirmation, no `-WhatIf`
  dry-run path, no "are you sure" for bulk deletes. A script that deletes list
  items should be auditable in a no-op mode first.
- **`-Force`:** bypasses safety prompts — justified, or papering over a problem?
- **`Set-*` on bulk:** mass field/permission updates with no preview of scope
  ("this will affect N items") and no rollback story.
- **Recycle bin vs permanent:** `-Recycle` vs hard delete. Hard deletes with no
  recovery path are Critical.
- **Idempotency / re-run safety:** if the script is run twice, does it duplicate
  or double-apply? Provisioning scripts especially.

## Large lists & throttling

- **5000-item threshold:** queries that will hit list-view threshold on real
  libraries — `Get-PnPListItem` without `-PageSize` pulling everything into
  memory, or CAML without indexed columns.
- **Batching:** bulk add/update/delete using `-Batch` / `Invoke-PnPBatch`, or
  one call per item (slow + throttle-prone)?
- **Throttling (429):** loops hammering the tenant with no delay/backoff. PnP
  handles some retry internally, but tight loops still get throttled.

## Error handling & loop safety

- **`$ErrorActionPreference`:** set to `Stop` where failures must halt, or left
  at `Continue` so the script silently sails past errors and reports success?
- **try/catch around per-item work:** one bad item shouldn't kill the whole run
  silently — or, conversely, shouldn't be swallowed so you can't tell what
  failed. Audit which behavior is intended and whether the code matches.
- **No silent continue:** loops that `catch {}` and move on with no log of which
  items failed.
- **Summary output:** does the script report what it actually changed (counts,
  ids), or finish with no evidence? An automation you can't audit after the
  fact is a reliability risk.

## Parameter & input safety

- **Mandatory params:** required inputs marked mandatory, or defaulted to
  something dangerous?
- **Validation:** `[ValidateSet]` / pattern checks on inputs that drive
  destructive ops.
- **Path/URL injection:** building queries or paths from unvalidated parameters.

## Example findings phrasing

- *Critical:* `Remove-PnPListItem` in a loop with `-Force` and no `-Recycle`,
  driven by a site URL parameter with no confirmation — a wrong URL permanently
  deletes the wrong library's items.
- *High:* `Get-PnPListItem` with no `-PageSize` against a library that exceeds
  the 5000 threshold — fails or loads everything into memory in prod.
- *Medium:* `$ErrorActionPreference` left at default; the update loop continues
  past failures and prints "Done" even when half the items errored.
