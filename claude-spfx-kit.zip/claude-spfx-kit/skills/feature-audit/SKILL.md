---
name: feature-audit
description: >-
  Statically audit existing application code for flaws, hidden bugs, error-path
  gaps, and reliability risks — WITHOUT executing anything. Use this skill
  whenever the user wants to verify a feature is solid, asks "is this working
  correctly", "find bugs", "review this for issues", "audit this", "what could
  break here", or wants assurance about an existing piece of functionality
  before shipping. Covers SPFx web parts/extensions (React 17 + TypeScript),
  Azure Functions / .NET backends, and PnP PowerShell automation. Trigger this
  even when the user just points at a file or feature and asks whether it's
  "fine" — a casual question about correctness still warrants a structured
  audit. Do NOT run, build, or modify code under this skill; it is read-only.
---

# Feature Audit (Static)

Audit a piece of existing functionality by reading the code and surrounding
context, then report flaws, latent bugs, and reliability risks. This is a
**read-only** review: do not execute, build, run tests, or modify files. The
goal is high-signal findings the developer can act on, ranked by how likely
each is to actually bite in production.

## Why static-only

Running code has side effects (writes to SharePoint lists, Graph calls,
deployments) that an audit must never trigger. A careful read catches the
majority of real defects — missing error handling, unhandled async, permission
gaps, untested edge cases — without touching anything live. If a finding can
only be confirmed by execution, say so explicitly rather than guessing.

## Workflow

1. **Scope it.** Identify the exact feature/files in question. If the user
   pointed at a folder or feature name, map the entry points first (web part
   class, function trigger, script top-level) and follow the call graph from
   there. Read the actual code — don't audit from memory of how SPFx "usually"
   works.
2. **Classify the runtime** of each file: SPFx/React, Azure Functions/.NET, or
   PnP PowerShell. Apply the matching checklist below. A mixed feature gets
   multiple checklists.
3. **Trace the unhappy paths.** Most hidden bugs live where things go wrong:
   empty results, API failures, throttling, null/missing fields, concurrent
   state. For each external call and each branch, ask "what happens when this
   fails or returns nothing?"
4. **Rank findings** by severity (see scale) — not by reading order.
5. **Report** using the exact structure below.

## Severity scale

- **Critical** — data loss, security/permission leak, silent corruption, or a
  crash on a common path.
- **High** — breaks on a realistic edge case (empty list, 429, expired token),
  or unhandled error that surfaces as a confusing failure to the user.
- **Medium** — works today but fragile: race-prone, untested branch, swallowed
  error, assumption that won't hold as data grows.
- **Low** — style/maintainability that correlates with future bugs (dead code,
  inconsistent error handling, magic values).

Always state *why* a finding sits at its severity, and how to confirm it.

## Report structure

ALWAYS use this exact template:

```
# Audit: [feature name]

## Summary
[2-3 sentences: overall health + the single most important finding.]

## Findings
### [Severity] — [short title]
- **Where:** file:line (or function/region)
- **Issue:** what's wrong
- **Impact:** what breaks, for whom, when
- **Confirm:** how to verify (test to write, input to try) — flag if it needs execution
- **Fix:** concrete suggestion
[repeat per finding, Critical first]

## What looks solid
[Briefly note things genuinely handled well — calibrates trust in the audit.]

## Not covered
[Anything out of static reach: runtime perf, real throttling behavior, infra config.]
```

Keep it scannable. If there are zero Critical/High findings, say so plainly
rather than inflating Mediums.

## Cross-cutting checks (all runtimes)

- **Error handling:** caught-and-swallowed errors (empty `catch`), errors logged
  but not surfaced, broad catches hiding real failures.
- **Null/empty:** what renders/returns when a source has 0 items, is null, or is
  undefined. Optional chaining masking a real "this should never be empty" bug.
- **Async correctness:** missing `await`, unhandled promise rejections,
  fire-and-forget calls, `Promise.all` where one rejection drops all results.
- **Boundary assumptions:** off-by-one, hardcoded limits, paging not followed.
- **Security:** secrets in code/logs, over-broad permissions, trusting client
  input, building queries/URLs by string concatenation.

## SPFx / React 17 + TypeScript checklist

Read `references/spfx.md` for the detailed checklist. Apply when auditing web
parts, extensions, or `spfx-toolkit`-based components. Key fast-checks:

- Graph/PnP calls: 429 throttling, partial batch failures, `@odata.nextLink`
  paging not followed, token/context expiry.
- Field-type parsing: lookup, managed-metadata, person, and multi-value fields
  mis-read as plain strings.
- React: `ErrorBoundary` actually wrapping the risky subtree; `useEffect`
  dependency/cleanup bugs; state set after unmount; render races.
- Permissions: ACL trimming, broken-inheritance edge cases, `ManageAccess`
  paths, elevated-context that leaks beyond its intended scope.
- TypeScript-strict: `any` escapes, non-null assertions (`!`) hiding real nulls,
  unsound casts.

## Azure Functions / .NET checklist

Read `references/azure-functions.md` for detail. Key fast-checks:

- Trigger contract: malformed input, missing fields, oversized payloads.
- Idempotency: what happens if the function runs twice on the same message
  (retries, at-least-once delivery)?
- External calls: timeout, retry, transient-fault handling; secrets pulled from
  config/Key Vault, never hardcoded.
- Async/`Task`: unawaited tasks, `.Result`/`.Wait()` deadlock risk, cancellation
  tokens ignored.
- Resource lifetime: `HttpClient` reuse, disposed/leaked connections.

## PnP PowerShell checklist

Read `references/pnp-powershell.md` for detail. Key fast-checks:

- Connection scope: which identity/site the script runs against; accidental
  cross-site or cross-tenant operations.
- Destructive ops: `Remove-*`, `Set-*` without confirmation, `-Force` on bulk
  operations, no `-WhatIf` path for dry runs.
- Throttling/large libraries: missing batching/paging on big list operations.
- Error mode: `$ErrorActionPreference` not set; loops that continue silently
  past failures; no summary of what actually changed.

## Example

**Input:** "Can you check my vendor-contract tagging web part? Want to make sure
it's actually working before I roll it out."

**Output:** A report headed `# Audit: vendor-contract tagging web part`, opening
with overall health, then findings ordered Critical→Low — e.g. flagging that the
Graph paging stops at the first 100 results (High), that a 429 from the tagging
call is swallowed and the user sees a blank success (High), and that the
person-field parse assumes single-value (Medium) — each with where/impact/
confirm/fix, then "what looks solid" and "not covered".
