---
name: pr-prep
description: >-
  Prepare an SPFx solution for a pull request: run lint and tsc and fix issues,
  enforce tight TypeScript, verify SharePoint service and spfx-toolkit usage,
  catch React re-render/memory-leak issues, sync the version across package.json
  and package-solution.json, validate the Deployments/<version> folder and its
  PowerShell scripts, check the provisioning Schema against the code, and ensure
  column/list names are referenced from the sp/ constants instead of hardcoded.
  Use this skill whenever the user is getting ready to open a PR, says "prep this
  for PR", "pr-prep", "is this ready to merge", "bump the version", "get this
  release-ready", or wants a pre-merge quality gate on an SPFx solution. Trigger
  it even when the user only mentions one part (e.g. "sync my versions") — the
  full gate is the intended workflow. Ask the user per category before applying
  fixes.
---

# SPFx PR Prep

A pre-merge quality gate for an SPFx solution. Work through every check below,
in order. This skill RUNS lint and tsc (real output, not guesses) and may apply
fixes — but **ask the user per category before changing files** (the user chose
"ask me per category"). Group findings by category, propose fixes, and apply
only the categories the user approves.

## Operating rules

- **Use real tool output.** Run the project's lint and `tsc` and base findings
  on actual results. Detect the exact commands from `package.json` scripts
  (e.g. `lint`, `build`); don't assume.
- **Ask before fixing, per category.** After analysis, present a grouped summary
  with a fix proposal per category. Apply fixes only for approved categories,
  then re-run lint/tsc to confirm. Never bulk-rewrite without approval.
- **Discover, don't assume.** The `sp/` constants structure, list/field names,
  and folder layout vary per solution — read the actual files first and infer
  the shape before judging code against them (see the constants check).
- **Be honest about confidence.** If a check needs runtime confirmation
  (actual provisioning behavior, real throttling), say so.

## Workflow

1. **Detect project shape.** Read `package.json` (scripts, version),
   `config/package-solution.json` (version), locate `src/`, the `sp/` constants
   folder, top-level `Deployments/` and `Schema/` folders. Note what exists.
2. **Run lint + tsc** using the detected commands. Capture real output.
3. **Work the checklist** (sections below), collecting findings per category.
4. **Present grouped report** with a fix proposal per category.
5. **Apply approved fixes**, re-run lint + tsc, confirm clean.
6. **Final summary** of what changed and what still needs human attention.

## Checklist

### 1. Lint
Run the project's lint script. Report errors and warnings. Propose auto-fix
(`--fix` equivalent) as one category. Don't silence rules to pass — flag any
rule that looks like it's hiding a real problem.

### 2. TypeScript tightness (tsc + strict)
- Run `tsc --noEmit` (or the build's type-check). Report every type error.
- Flag `any` / `as any`, non-null assertions (`!`), and unsound casts of API
  responses to interfaces without runtime validation — these defeat TS-strict
  exactly where data shape matters most.
- Flag implicit `any`, missing return types on exported functions, and
  `@ts-ignore` / `@ts-expect-error` without a reason comment.

### 3. SharePoint service & spfx-toolkit usage
Read `references/spfx-standards.md` for detail. Key checks:
- SharePoint data access goes through the project's SP service layer / SPContext
  utility, not ad-hoc `sp.web...` scattered in components.
- `spfx-toolkit` components used where applicable (Card, spForm, ErrorBoundary,
  Toast/Notification) rather than re-implementing them; imports use the direct
  path form (`spfx-toolkit/lib/...`) for tree-shaking.
- `spUpdater` change detection and `SPContext` caching used as intended.

### 4. React health (re-render / leaks)
Read `references/spfx-standards.md`. Key checks:
- `useEffect` dependency arrays correct (no stale closures, no infinite loops);
  cleanup present for subscriptions/timers; no `setState` after unmount.
- Unnecessary re-renders: inline object/array/function props recreated each
  render; missing `useMemo`/`useCallback` where it matters; list keys.
- ErrorBoundary actually wraps risky subtrees; async errors handled (boundaries
  don't catch those).

### 5. Constants — no hardcoded list/field/group names
This is a hard house rule. Read `references/constants-check.md` for the full
procedure. Summary:
- First READ the `sp/` constants folder and infer its structure (nested objects,
  flat consts, enums — discover it, don't assume).
- Then scan `src/` for **string literals** that name lists, fields (internal
  names), content types, or site groups that should instead reference the `sp/`
  constants.
- Report each hardcoded occurrence with the constant it should use. Propose the
  replacement as a fix category.

### 6. Version sync (package.json ↔ package-solution.json)
Read `references/version-and-deployments.md`. Rule:
- `package.json` uses 3-part semver (e.g. `1.2.0`).
- `config/package-solution.json` uses 4-part (e.g. `1.2.0.0`) — the first three
  parts MUST equal the package.json version.
- Report mismatch; propose syncing both to the intended version as a fix
  category. Confirm the target version with the user if ambiguous.

### 7. Deployments/<version> folder
Read `references/version-and-deployments.md`. Checks:
- A `Deployments/<version>` folder exists matching the package.json version
  (e.g. `Deployments/1.2.0`).
- It contains `readme.md` describing the changes in this version; flag if
  missing or empty.
- If `pre.deployment.ps1` / `post.deployment.ps1` exist, sanity-check them (see
  PowerShell checks below). They're optional per deployment — absence is fine,
  but a broken one is not.

### 8. Schema folder vs code
Read `references/version-and-deployments.md`. Checks:
- Cross-check the provisioning schema in top-level `Schema/` against the code:
  every list the code reads/writes should exist in schema; every field the code
  references (via the `sp/` constants) should exist on the right list in schema,
  with a compatible type.
- Flag fields used in code but missing from schema (provisioning gap) and fields
  in schema never referenced (possible dead schema) — report the former as
  higher severity.

### 9. PowerShell sanity (pre/post deployment .ps1)
Read `references/powershell-deploy.md`. For any deployment script:
- Connection scope correct; no hardcoded secrets.
- Destructive ops guarded (`-WhatIf` path, `-Recycle` over hard delete,
  confirmation on bulk ops).
- `$ErrorActionPreference` set so failures halt rather than silently continue.
- Idempotent / re-runnable (deployments get retried).

## Report structure

ALWAYS present findings grouped by category, each with a fix proposal the user
can approve or skip:

```
# PR Prep: [solution] → v[target version]

## Lint            [N errors, M warnings]  → propose: auto-fix
## TypeScript      [N errors, K loose-typing flags] → propose: ...
## SP / toolkit    [findings] → propose: ...
## React           [findings] → propose: ...
## Constants       [N hardcoded names] → propose: replace with sp/ constants
## Version sync    [package.json X ↔ package-solution Y] → propose: sync to Z
## Deployments     [folder/readme/ps1 status] → propose: ...
## Schema          [code↔schema gaps] → propose: ...
## PowerShell      [findings] → propose: ...

Reply with which categories to fix (e.g. "fix lint, version, constants").
```

After applying approved fixes, re-run lint + tsc and report the clean (or
remaining) state, plus anything left for human attention.

## Additional standards worth enforcing

Beyond what the user specified, these fit the same pre-PR gate (propose, don't
impose): localization strings not hardcoded in components; no `console.log`
left in shipping code; bundle-size sanity (no accidental full-library imports,
e.g. `import * as` from large packages); solution/manifest IDs unchanged unless
intended; `.gitignore` keeping build artifacts out; and a quick check that the
`Deployments/<version>/readme.md` actually reflects the diff in this PR.
