# PowerShell Deploy-Script Sanity (section 9)

Light sanity check for `pre.deployment.ps1` / `post.deployment.ps1` in a
`Deployments/<version>` folder. These run around a solution deployment, often
against a live tenant, so the bar is "won't silently break the deploy or do
something destructive unintentionally."

## Connection & scope
- `Connect-PnPOnline` (or equivalent) targets the intended site/tenant; the URL
  isn't accidentally hardcoded to the wrong environment.
- No hardcoded secrets/passwords in plaintext — use app-only/cert/managed
  identity or a secure prompt.

## Destructive operations
- `Remove-*` / mass `Set-*` guarded: a `-WhatIf` dry-run path exists, `-Recycle`
  used over permanent delete where possible, confirmation on bulk operations.
- `-Force` used only where justified, not to paper over a prompt.

## Error handling & idempotency
- `$ErrorActionPreference = 'Stop'` (or per-call `-ErrorAction Stop`) where a
  failure must halt the deployment rather than continue silently and report
  success.
- Idempotent / re-runnable: deployments get retried. Adding a field, group, or
  list should no-op if it already exists rather than erroring or duplicating.
- Per-item work in loops logs which items failed; the script ends with a summary
  of what it actually changed, so the deploy is auditable.

## Large operations
- Bulk list operations use batching / paging; tight loops don't hammer the
  tenant without backoff.

## Reporting
Report findings at the same severity scale used elsewhere (Critical for
unguarded permanent deletes against a parameterized site; High for
silent-continue-on-error during deploy; Medium for missing summary/idempotency).
Remember these scripts are optional — only check the ones that exist, and a
clean/absent script is a pass.
