# SPFx Standards — Service, Toolkit, React

Detailed checks for sections 3 and 4 of the PR-prep checklist.

## SharePoint service-layer usage

The goal: data access is centralized and consistent, not scattered.

- **Centralized access:** SharePoint reads/writes should flow through the
  project's SP service layer or the `SPContext` utility, not raw `sp.web.lists...`
  calls dropped directly inside React components. Ad-hoc access in components is
  hard to cache, test, and audit. Flag component-level direct PnP calls that
  bypass the service layer.
- **SPContext caching:** caching/pessimistic strategy used as designed; no
  duplicate context initialization; cached values not held past their validity.
- **Error surfacing:** service errors propagated to the UI (Toast/Notification),
  not swallowed in the service.
- **Paging & throttling:** collection reads follow `@odata.nextLink` / use paged
  retrieval; 429 handling present on heavy calls (don't let prod-size libraries
  silently truncate at the first page).

## spfx-toolkit usage

- **Reuse over re-implementation:** where the toolkit already provides it (Card,
  spForm, WorkflowStepper, ErrorBoundary, ManageAccess/GroupViewer, Toast), the
  code should use it rather than hand-rolling a parallel version. Flag
  reimplementations.
- **Direct-path imports:** imports use `spfx-toolkit/lib/...` form for
  tree-shaking, not a barrel import that pulls the whole package into the bundle.
- **spForm:** Zod validation wired to submit; React Hook Form + DevExtreme + PnP
  controls used consistently; validation failures block submit.
- **spUpdater:** change detection used for saves; watch for `isEqual`
  false-negatives on nested/reference-equal objects that silently skip a save.
- **ErrorBoundary:** present around risky subtrees with appropriate
  severity/category classification.

## React health — re-render & memory leaks

### Unnecessary re-renders
- **Inline props recreated each render:** object/array/function literals passed
  as props (`style={{...}}`, `onClick={() => ...}`, `items={[...]}`) defeat memo
  and re-render children every time. Flag in hot paths / large lists.
- **Missing memoization where it matters:** expensive computed values without
  `useMemo`; callbacks passed to memoized children without `useCallback`. Don't
  over-prescribe memoization everywhere — only where there's a real render cost.
- **Context value identity:** a context `value={{...}}` recreated each render
  re-renders all consumers.
- **List keys:** stable unique keys, not array index (index keys cause state
  bleed and extra reconciliation).

### Memory leaks & lifecycle
- **useEffect cleanup:** subscriptions, timers, event listeners, and async
  watchers cleaned up in the return function.
- **setState after unmount:** state set inside a resolved promise/async callback
  after the component unmounted — guard with an "is mounted"/abort check or
  cancel the request.
- **Dependency arrays:** correct deps (no stale closures); no missing deps that
  ESLint's react-hooks rule would flag; no effects that loop because a dep is
  recreated each render.
- **Abort on unmount:** in-flight fetches cancelled (AbortController) so a fast
  unmount/remount doesn't leave a late response writing stale state.

### Extension lifecycle (application / field / form customizers)
For code in `src/extensions/`, the dispose half of the lifecycle is the usual
leak source and runs broadly (every page, or every cell per row):
- **Application Customizer:** placeholders acquired safely and disposed on
  navigation; `onInit` not blocking render; injected React root unmounted on
  dispose.
- **Field Customizer:** every `onRenderCell` paired with `onDisposeCell`
  teardown; no heavy work or data calls inside `onRenderCell`; cell value parsed
  for the real column type.
- **Form Customizer:** `onSave` validates and surfaces failures; New/Edit/Display
  modes handled; React root unmounted on close.
- **Registration:** `ClientSideComponentId` / `ClientSideComponentProperties`
  match the manifest and typed props; tenant/list scope is deliberate.
