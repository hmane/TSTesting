# Version, Deployments & Schema

Detailed procedure for sections 6, 7, and 8.

## Version sync (section 6)

Two files carry the version and must agree:

- `package.json` → `version`, 3-part semver, e.g. `1.2.0`.
- `config/package-solution.json` → `solution.version`, 4-part, e.g. `1.2.0.0`.

**Rule:** the first three parts of the 4-part version equal the package.json
version. So `1.2.0` ↔ `1.2.0.0`. The 4th part is the build/revision segment.

Procedure:
1. Read both versions.
2. If the first three parts don't match, it's a finding.
3. Determine the intended target version — usually the higher of the two, or ask
   the user if it's ambiguous (a release may intend a bump neither file shows
   yet).
4. Propose: set `package.json` to `X.Y.Z` and `package-solution.json` to
   `X.Y.Z.W` (preserve or reset the 4th part per the team's convention; if
   unknown, keep the existing 4th part, default `0`).

The target version also drives the Deployments folder check below — they must
agree.

## Deployments/<version> folder (section 7)

Top-level `Deployments/` holds one folder per released version.

- A folder named exactly for the package.json version must exist, e.g.
  `Deployments/1.2.0` (3-part, matching package.json, not the 4-part form).
- Inside it, `readme.md` describing the changes in this version. Flag if missing
  or empty. Cross-check it against the PR diff: does the readme actually reflect
  what changed? A stale/placeholder readme is a finding.
- `pre.deployment.ps1` and `post.deployment.ps1` are OPTIONAL and depend on the
  specific deployment. Absence is fine. If present, sanity-check them via the
  PowerShell reference. A missing script is not a problem; a broken one is.

If the version was just bumped, the matching `Deployments/<new version>` folder
may not exist yet — propose creating it with a `readme.md` scaffold listing the
PR's changes.

## Schema folder vs code (section 8)

Top-level `Schema/` holds the provisioning schema for the solution (lists,
fields, content types, etc.). Goal: the schema and the code agree.

Procedure:
1. Parse the schema: enumerate lists, and for each list its fields (internal
   name + type).
2. From the code (via the `sp/` constants and the constants map built in the
   constants check), enumerate which lists and fields the code actually
   reads/writes.
3. Cross-check both directions:
   - **Code → schema (higher severity):** a list or field the code uses that is
     missing from schema = provisioning gap. On deploy, the code will hit a
     field that doesn't exist. Report as High.
   - **Field type mismatch:** field exists in schema but the type conflicts with
     how code treats it (e.g. code expects a lookup, schema says single line of
     text). Report as High.
   - **Schema → code (lower severity):** a list/field in schema that nothing
     references = possibly dead schema or a future field. Report as Low/info,
     not a blocker.
4. Account for indirection: the `sp/` constants are generated from the live
   site, so a mismatch between schema and constants can mean the schema wasn't
   updated when a field was added. Note that interpretation in the finding.

This check is static inference — note that actual provisioning behavior (e.g.
field provisioning order, dependent lookups) can only be fully confirmed by
running provisioning. Say so where relevant.
